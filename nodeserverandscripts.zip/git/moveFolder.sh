#!/bin/bash

# Input string

packageName="$1"

SOURCE="/opt/wm/is1015/IntegrationServer/instances/esb_5255/packages/"
DESTINATION="/opt/wm/git/aia-server-5255/IS/packages/"
mkdir $DESTINATION/$packageName
cp -r "$SOURCE/$packageName/"* "$DESTINATION/$packageName/"