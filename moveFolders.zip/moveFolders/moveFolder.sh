#!/bin/bash

# Input string

packageName="$1"

SOURCE="C:/SoftwareAG/IntegrationServer/instances/default/packages/"
DESTINATION="C:/Users/vkraft/pubsubusingkafkaandwebmrepo/aia-server-5055"
mkdir $DESTINATION/$packageName
cp -r "$SOURCE/$packageName/"* "$DESTINATION/$packageName/"
